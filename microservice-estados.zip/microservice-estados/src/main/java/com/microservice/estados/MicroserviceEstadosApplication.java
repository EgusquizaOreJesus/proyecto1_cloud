package com.microservice.estados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceEstadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceEstadosApplication.class, args);
	}

}
