package com.microservice.estados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceEstadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
