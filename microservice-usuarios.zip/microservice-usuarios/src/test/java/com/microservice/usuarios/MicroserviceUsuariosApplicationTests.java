package com.microservice.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
