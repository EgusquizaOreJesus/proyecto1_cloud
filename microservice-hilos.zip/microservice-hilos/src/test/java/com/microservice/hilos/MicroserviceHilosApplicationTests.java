package com.microservice.hilos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceHilosApplicationTests {

	@Test
	void contextLoads() {
	}

}
