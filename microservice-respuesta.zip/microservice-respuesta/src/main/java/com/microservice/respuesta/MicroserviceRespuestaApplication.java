package com.microservice.respuesta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceRespuestaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceRespuestaApplication.class, args);
	}

}
