package com.microservice.respuesta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceRespuestaApplicationTests {

	@Test
	void contextLoads() {
	}

}
